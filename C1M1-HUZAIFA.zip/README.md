This repo contains the assessment 1 files that represents a simple program to do some operations on a given array, the assessment requires the code to be well documented and also to use the git version control.

Author: Huzaifa



