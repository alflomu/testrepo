Project for Coursera Introduction to Embedded Systems
