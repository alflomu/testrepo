/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file <Add File Name> 
 * @brief <Add Brief Description Here >
 *
 * <Add Extended Description Here>
 *
 * @author Luis Flores
 * @date 07/04/2025
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)


void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */
  printf("Original Array:\n");
  print_array(test,SIZE);
  printf("\nCalculating Statistics...");
  print_statistics(test,SIZE);
  printf("\nArray after sorting\n");
  print_array(test,SIZE);
}

/* Add other Implementation File Code Here */
unsigned char find_minimum(unsigned char* arr,unsigned int len){
	unsigned char min = arr[0];
	for(int i =1;i<len;i++){
		if (arr[i]<min){
			min=arr[i];
		}
	}
	return min;
}

unsigned char find_maximum(unsigned char* arr,unsigned int len){
	unsigned char max = arr[0];
	for(int i =1;i<len;i++){
		if (arr[i]>max){
			max=arr[i];
		}
	}
	return max;
}

void print_array(unsigned char* arr,unsigned int len){
	for(int i =0;i<len;i++){
	  printf("Element %d: %d\n",i,arr[i]);
		
	}
	
}

void sort_array(unsigned char* arr,unsigned int len){
  for(int i = 0;i < len; i++){
    
    for(int j=0;j < len - 1; j++){
       
	if(arr[j] < arr[j+1]){
              int temp = arr[j];
              arr[j] = arr[j+1];
              arr[j+1] = temp;
         }
    }
  }
}

float find_median(unsigned char* arr,unsigned int len){
  float median;
  sort_array(arr,len);
  int middle=len/2;

  if(len%2==0){  
    median= ((float)arr[middle-1]+arr[middle])/2.0f;
    return median;
  }
    median = arr[middle];
    return median;
}

float find_mean(unsigned char* arr,unsigned int len){
  int sum=0;
  for(int i=0;i<len;i++){
  sum+=arr[i];
  }
  float mean = (float)sum/len;
  return mean;
  
}

void print_statistics(unsigned char* arr,unsigned int len){
  printf("\nMinimum: %d \n",find_minimum(arr,len));
  printf("Maximum: %d \n",find_maximum(arr,len));
  printf("Median: %f \n",find_median(arr,len));
  printf("Mean: %f \n",find_mean(arr,len));

}






