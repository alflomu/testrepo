/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief Function definitions
 *
 * <Add Extended Description Here>
 *
 * @author Luis Flores
 * @date 07/05/2025
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 

/**
 * @brief Prints the elements of an array to the console.
 *
 * This function iterates through the array and prints each unsigned char value,
 * separated by commas, enclosed in square brackets. It handles empty arrays gracefully.
 *
 * @param arr Pointer to the unsigned char array to be printed.
 * @param len The number of elements in the array.
 *
 * @return void
 */
void print_array(unsigned char* arr,unsigned int len);

/**
 * @brief Finds the minimum value in an array.
 *
 * This function iterates through the array to find the smallest value.
 *
 * @param arr Pointer to the unsigned char array.
 * @param len The number of elements in the array.
 *
 * @return The minimum value found in the array as an unsigned char.
 */
unsigned char find_minimum(unsigned char* arr, unsigned int len);

/**
 * @brief Finds the maximum value in an array.
 *
 * This function iterates through the array to find the largest value.
 *
 * @param arr Pointer to the unsigned char array.
 * @param len The number of elements in the array.
 *
 * @return The maximum value found in the array as an unsigned char.
 */
unsigned char find_maximum(unsigned char* arr, unsigned int len);

/**
 * @brief Sorts an array from largest to smallest (descending order).
 *
 * This function uses a bubble sort algorithm to reorder the elements
 * of the array such that the largest value is at index 0 and the smallest
 * value is at the last index (len-1). The sorting is done in-place.
 *
 * @param arr Pointer to the unsigned char array to be sorted.
 * @param len The number of elements in the array.
 *
 * @return void
 */
void sort_array(unsigned char* arr,unsigned int len);


/**
 * @brief Finds the median value of an array.
 *
 * This function first sorts the array in descending order and then calculates
 * the median. If the array has an even number of elements, the median is the
 * average of the two middle elements. If it has an odd number, it's the middle element.
 *
 * @param arr Pointer to the unsigned char array. The array will be sorted in place.
 * @param len The number of elements in the array.
 *
 * @return The median value as a float.
 */
float find_median(unsigned char* arr,unsigned int len);

/**
 * @brief Finds the mean (average) value of an array.
 *
 * This function sums all elements in the array and divides by the total number of elements.
 *
 * @param arr Pointer to the unsigned char array.
 * @param len The number of elements in the array.
 *
 * @return The mean value as a float.
 */
float find_mean(unsigned char* arr,unsigned int len);

/**
 * @brief Prints the calculated statistics of an array.
 *
 * This function computes and displays the minimum, maximum, mean, and median
 * values of the given array. It handles cases where the array is empty.
 * Note: Calling this function will sort the array in place due to find_median.
 *
 * @param arr Pointer to the unsigned char array.
 * @param len The number of elements in the array.
 *
 * @return void
 */
void print_statistics(unsigned char* arr,unsigned int len);


#endif /* __STATS_H__ */
