/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Function declarations for statistics operations
 *
 * This file contains function declarations to analyze an array of unsigned char data items 
 * and compute their statistical properties like minimum, maximum, mean, and median.
 *
 * @author Hemavathi
 * @date 05-07-2025
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

void print_statistics(unsigned char *arr, int size);

/**
 * @brief Prints statistics of an array
 *
 * This function prints the minimum, maximum, mean, and median
 * of the given data array to the standard output.
 
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return Void (no return value)
 */

void print_array(unsigned char *arr, int size);

/**
 * @brief Prints the array elements
 *
 * This function prints each element of the given array to the screen.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return Void (no return value)
 */

void sort_array(unsigned char *arr, int size);

/**
 * @brief Sorts the array from largest to smallest
 *
 * This function sorts the data array in descending order (highest to lowest).
 * The zeroth element will be the largest, and the last will be the smallest.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return Void (no return value)
 */

int find_maximum(unsigned char *arr, int size);

/**
 * @brief Finds the maximum value in the array
 *
 * This function iterates through the array to find and return
 * the maximum value stored in the array.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return The maximum value as an integer
 */

int find_minimum(unsigned char *arr, int size);

/**
 * @brief Finds the minimum value in the array
 *
 * This function iterates through the array to find and return
 * the minimum value stored in the array.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return The minimum value as an integer
 */

int find_mean(unsigned char *arr, int size);

/**
 * @brief Calculates the mean of the array
 *
 * This function calculates and returns the average (mean)
 * value of the elements in the array.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return The mean value as an integer
 */

int find_median(unsigned char *arr, int size);

/**
 * @brief Finds the median value in the array
 *
 * This function returns the median of the array. It assumes the array is already sorted.
 * If the number of elements is even, it returns the average of the two middle values.
 * If the number is odd, it returns the middle element.
 *
 * @param arr Pointer to the unsigned char array
 * @param size Integer representing the size of the array
 *
 * @return The median value as an integer
 */

#endif /* __STATS_H__ */
