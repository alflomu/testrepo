/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c 
 * @brief Performs statistical operations on an array
 *
 * This file contains the implementation of functions to find
 * minimum, maximum, mean, and median from a data array.
 *
 * @author Hemavathi
 * @date 05-07-2025
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

int main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  sort_array(test, SIZE);
  print_statistics(test, SIZE);
  printf("\n");
  print_array(test, SIZE);
  find_maximum(test, SIZE);
  find_minimum(test, SIZE);
  find_mean(test, SIZE);
  find_median(test, SIZE);

  return 0;
  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */

}

/* Add other Implementation File Code Here */

void print_statistics(unsigned char *arr, int size) {
  int min=find_minimum(arr, SIZE);
    printf("\n The minimum value of the array is %d", min);
    int max=find_maximum(arr, SIZE);
    printf("\n The maximum value of the array is %d", max);
    int mean=find_mean(arr, SIZE);
    printf("\n The mean of the array is %d", mean);
    int median=find_median(arr, SIZE);
    printf("\n The median of the array is %d", median);
}

void print_array(unsigned char *arr, int size) {
  for (int i=0;i<size;i++){
        printf("\t %d", arr[i]);
    }
}

void sort_array(unsigned char *arr, int size) {
  for(int i=0;i<size;i++){
        for(int j=i+1;j<size;j++){
            if(arr[i]<arr[j]){
            int c = arr[i];
            arr[i]=arr[j];
            arr[j]=c;
        }
        }
            }
}

int find_maximum(unsigned char *arr, int size) {
  int max=arr[0];
    for(int j=1;j<size;j++){
            if(max<arr[j]){
            max = arr[j];
            }
    }
    return max;
}

int find_minimum(unsigned char *arr, int size) {
 int min=arr[0];
    for(int j=1;j<size;j++){
        if(min>arr[j]){
            min=arr[j];
        }
    }
    return min; 
}

int find_mean(unsigned char *arr, int size) {
 int c=0;
    for(int i=0;i<size;i++){
        c+=arr[i];
    }
    c=c/size;
    return c;
}

int find_median(unsigned char *arr, int size) {
  int a=size/2;
    int median;
if(size % 2==0){
    median=(arr[a-1]+arr[a])/2;
}
else{
    median=arr[a];
}
return median;
}
