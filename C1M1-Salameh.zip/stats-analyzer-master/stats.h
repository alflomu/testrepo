/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Header file for array statistics functions
 *
 * Contains declarations for functions that analyze and manipulate 
 * an array of unsigned characters, including finding statistics 
 * such as mean, median, max, and min, as well as sorting.
 *
 * @author Salameh
 * @date 2025-07-06
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Prints statistics (min, max, mean, median) of an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 */
void print_statistics(unsigned char *array, unsigned int length);

/**
 * @brief Prints the elements of an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 */
void print_array(unsigned char *array, unsigned int length);

/**
 * @brief Finds the median of an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 * @return Median value
 */
unsigned char find_median(unsigned char *array, unsigned int length);

/**
 * @brief Finds the mean of an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 * @return Mean value
 */
unsigned char find_mean(unsigned char *array, unsigned int length);

/**
 * @brief Finds the maximum value in an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 * @return Maximum value
 */
unsigned char find_maximum(unsigned char *array, unsigned int length);

/**
 * @brief Finds the minimum value in an array
 *
 * @param array Pointer to the array
 * @param length Length of the array
 * @return Minimum value
 */
unsigned char find_minimum(unsigned char *array, unsigned int length);

/**
 * @brief Sorts the array from largest to smallest
 *
 * @param array Pointer to the array
 * @param length Length of the array
 */
void sort_array(unsigned char *array, unsigned int length);

#endif /* __STATS_H__ */
