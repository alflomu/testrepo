/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief Header file
 *
 * @author Samuel Yow
 * @date 06/07/2025
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 

/**
 * @brief <Add Brief Description of Function Here>
 *
 * <Add Extended Description Here>
 *
 * @param <Add InputName> <add description here>
 * @param <Add InputName> <add description here>
 * @param <Add InputName> <add description here>
 * @param <Add InputName> <add description here>
 *
 * @return <Add Return Informaiton here>
 */
 
/**
 * @brief print statistics of array including minimum, maximum, mean 
 * and median
 *
 * @param array pointer to char array
 * @param length length of array
 */
void print_statistics(unsigned char *array, int length);
 
/**
 * @brief prints the array to the screen
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 */
void print_array(unsigned char *array, int length);
 
/**
 * @brief Given an array of data and a length, returns the median value
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 * @return median value
 *
 */
unsigned int find_median(unsigned char *array, unsigned int length);
 
/**
 * @brief Given an array of data and a length, returns the mean
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 * @return mean value
 *
 */
unsigned int find_mean(unsigned char *array, unsigned int length);
 
/**
 * @brief Given an array of data and a length, returns the maximum
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 * @return maximum value
 *
 */
unsigned int find_maximum(unsigned char *array, unsigned int length);
 
/**
 * @brief Given an array of data and a length, returns the minimum
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 * @return minimum value
 *
 */
unsigned int find_minimum(unsigned char *array, unsigned int length);
 
 
/**
 * @brief Given an array of data and a length, sorts the array from largest to smallest
 *
 * @param array pointer to unsigned char array
 * @param length length of array
 *
 *
 */
void sort_array(unsigned char *array, unsigned int length);
 


#endif /* __STATS_H__ */
