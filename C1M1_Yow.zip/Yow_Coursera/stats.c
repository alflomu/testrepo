/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief Analyze array of unsigned char data items and report analytics on
 * max, min, mean and medium of dataset. Also recorder dataset from large to small
 *
 * @author Samuel Yow
 * @date 06/07/2025
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */

  /* Statistics and Printing Functions Go Here */
  printf("Original Array\r\n");
  print_array(test, SIZE);
  print_statistics(test, SIZE);

  printf("Sorted Array\r\n");
  print_array(test, SIZE);

}

/* Add other Implementation File Code Here */

void print_statistics(unsigned char *array, int length){
  printf("Min number: %i\r\n", find_minimum(array,  length));
  printf("Max number: %i\r\n", find_maximum(array,  length));
  printf("Mean of array: %i\r\n", find_mean(array,  length));

  sort_array(array, length);
  printf("Median of array: %i\r\n", find_median(array,  length));
  
}
 
void print_array(unsigned char *array, int length){
  printf("[");

  for(int i = 0; i < length; i++)
  {
    printf("%i ", array[i]);
  }

  printf("]\r\n");
}
 
unsigned int find_median(unsigned char *array, unsigned int length){
  if(length%2 == 0){
    int first_pos = length/2;
    int sec_pos = length/2+1;
    return (array[first_pos] + array[sec_pos])/2;
  }
  else{
    return array[length/2 + 1];
  }
}
 
unsigned int find_mean(unsigned char *array, unsigned int length){
  unsigned int total_sum = 0;

  for(int i = 0; i < length; i++){
    total_sum += array[i];
  }

  return total_sum/length;
}

unsigned int find_maximum(unsigned char *array, unsigned int length){
  unsigned int max_number = 0;
  
  for(int i = 0; i < length; i++){
    if (array[i] > max_number){
      max_number = array[i];
    }
  }

  return max_number;
}

unsigned int find_minimum(unsigned char *array, unsigned int length){
  unsigned int min_number = 0xFFFF; //Largest possible number for unsigned int
  
  for(int i = 0; i < length; i++){
    if (array[i] < min_number){
      min_number = array[i];
    }
  }

  return min_number;
}

void sort_array(unsigned char *array, unsigned int length)
{
  //Simple implementation: bubble sort
  int sorted = 1;
  unsigned int temp_var;

  do
  {
    sorted = 1;

    for(int i = 0; i < length-1; i++)
    {
      if(array[i] < array[i+1])
      {
        temp_var = array[i];
        array[i] = array[i+1];
        array[i+1] = temp_var;
        sorted = 0;
      }
    }
  
  }while(sorted == 0);

}
